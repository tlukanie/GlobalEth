# AI Console Chat - Question Answering

A Node.js + TypeScript console application that allows you to chat with AI question-answering models from Hugging Face directly in your terminal.

## Features

- Interactive console-based question answering interface
- Uses Hugging Face's Inference API with QA models
- Set custom context for your questions
- Commands to manage your conversation context
- Colorful terminal output for better readability

## Prerequisites

- Node.js 16.x or higher
- A Hugging Face account and API token

## Setup

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Run the application:
   ```
   npm run dev
   ```
4. On first run, it will create a `.env` file from `.env.example`. Edit the `.env` file and add your Hugging Face API token:
   ```
   HUGGINGFACE_API_TOKEN=your_huggingface_api_token_here
   ```
5. Run the application again to start chatting:
   ```
   npm run dev
   ```

## Configuration

You can configure the following in the `.env` file:

- `HUGGINGFACE_API_TOKEN`: Your Hugging Face API token (required)
- `MODEL_ID`: The model ID to use (default: `deepset/roberta-base-squad2`)

## Recommended Question-Answering Models

The following models work well with this application:

- `deepset/roberta-base-squad2`: High-quality question-answering model (default)
- `distilbert/distilbert-base-uncased-distilled-squad`: Smaller, faster model
- `timpal0l/mdeberta-v3-base-squad2`: Modern performance model
- `google-bert/bert-large-uncased-whole-word-masking-finetuned-squad`: Google's BERT model

## Usage

- Set a custom context when starting the application, or use the default
- Type your questions and get AI-powered answers
- Use special commands to manage your session:
  - `!context` - Change the current context
  - `!showcontext` - Display the current context
  - `!help` - Show available commands
  - `exit` - Quit the application

## How It Works

1. You provide a context - this is the text the model uses to find answers
2. You ask specific questions about that context
3. The model extracts relevant information from the context to answer your questions

## Building for Production

To build the application for production:

```
npm run build
npm start
```

## License

ISC
