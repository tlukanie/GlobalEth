import { HfInference } from "@huggingface/inference";
import readlineSync from "readline-sync";
import dotenv from "dotenv";
import path from "path";
import fs from "fs";

// Load environment variables
dotenv.config();

// Check if .env file exists, if not, create one from .env.example
const envPath = path.resolve(process.cwd(), ".env");
const envExamplePath = path.resolve(process.cwd(), ".env.example");

if (!fs.existsSync(envPath) && fs.existsSync(envExamplePath)) {
  fs.copyFileSync(envExamplePath, envPath);
  console.log(
    "\x1b[33m%s\x1b[0m",
    "Created .env file from .env.example. Please edit it with your Hugging Face API token."
  );
  process.exit(0);
}

// Get API token from environment variables
const apiToken = process.env.HUGGINGFACE_API_TOKEN;
const modelId = process.env.MODEL_ID || "deepset/roberta-base-squad2";

// Check if API token is provided
if (!apiToken || apiToken === "your_huggingface_api_token_here") {
  console.error(
    "\x1b[31m%s\x1b[0m",
    "Error: Hugging Face API token not found."
  );
  console.log("Please add your API token to the .env file:");
  console.log("HUGGINGFACE_API_TOKEN=your_token_here");
  process.exit(1);
}

// Initialize Hugging Face Inference client
const hf = new HfInference(apiToken);

// Main conversation function
async function startConversation() {
  console.log("\x1b[36m%s\x1b[0m", `AI Console Chat - Using model: ${modelId}`);
  console.log("\x1b[36m%s\x1b[0m", 'Type "exit" to quit the application');
  console.log(
    "\x1b[36m%s\x1b[0m",
    "This is a question-answering system. Ask a clear question for best results."
  );
  console.log("-".repeat(50));

  // Conversation history for context - keeping recent questions for reference
  const questionHistory: string[] = [];
  const answerHistory: string[] = [];

  // Default context if none is set
  let context =
    "The AI assistant can answer questions based on provided context. If no specific context is provided, it will use general knowledge.";

  // Ask if user wants to set a custom context
  const setCustomContext = readlineSync.keyInYN(
    "\x1b[32mWould you like to set a custom context for your questions? \x1b[0m"
  );

  if (setCustomContext) {
    console.log(
      "\x1b[36m%s\x1b[0m",
      "Enter your context below (this will be used for all questions until you change it):"
    );
    context = readlineSync.question("\x1b[32mContext: \x1b[0m");
    console.log("\x1b[36m%s\x1b[0m", "Context set successfully!");
    console.log("-".repeat(50));
  }

  while (true) {
    // Get user input
    const userInput = readlineSync.question("\x1b[32mYour question: \x1b[0m");

    // Check if user wants to exit
    if (userInput.toLowerCase() === "exit") {
      console.log("\x1b[36m%s\x1b[0m", "Goodbye!");
      break;
    }

    // Check if user wants to change context
    if (userInput.toLowerCase() === "!context") {
      console.log("\x1b[36m%s\x1b[0m", "Enter your new context below:");
      context = readlineSync.question("\x1b[32mNew context: \x1b[0m");
      console.log("\x1b[36m%s\x1b[0m", "Context updated successfully!");
      continue;
    }

    // Check if user wants to see current context
    if (userInput.toLowerCase() === "!showcontext") {
      console.log("\x1b[36m%s\x1b[0m", "Current context:");
      console.log("\x1b[33m%s\x1b[0m", context);
      continue;
    }

    // Check if user wants to see help
    if (userInput.toLowerCase() === "!help") {
      console.log("\x1b[36m%s\x1b[0m", "Available commands:");
      console.log("\x1b[33m%s\x1b[0m", "exit - Exit the application");
      console.log("\x1b[33m%s\x1b[0m", "!context - Change the current context");
      console.log(
        "\x1b[33m%s\x1b[0m",
        "!showcontext - Show the current context"
      );
      console.log("\x1b[33m%s\x1b[0m", "!help - Show this help message");
      continue;
    }

    // Add user question to history
    questionHistory.push(userInput);
    if (questionHistory.length > 5) {
      questionHistory.shift(); // Keep only last 5 questions
    }

    try {
      // Display "thinking" animation
      const loadingInterval = setInterval(() => {
        process.stdout.write("\x1b[35m.\x1b[0m");
      }, 300);

      // Call the API
      const response = await hf.questionAnswering({
        model: modelId,
        inputs: {
          question: userInput,
          context: context,
        },
      });

      // Clear the loading animation
      clearInterval(loadingInterval);
      process.stdout.write("\r\x1b[K");

      // Extract and display the assistant's response
      const answer = response.answer;
      console.log("\x1b[34mAnswer: \x1b[0m" + answer);

      // Add answer to history
      answerHistory.push(answer);
      if (answerHistory.length > 5) {
        answerHistory.shift(); // Keep only last 5 answers
      }
    } catch (error) {
      console.error("\x1b[31mError:\x1b[0m", error);
      console.log('\x1b[33mTry again or type "exit" to quit.\x1b[0m');
    }
  }
}

// Start the conversation
startConversation().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
