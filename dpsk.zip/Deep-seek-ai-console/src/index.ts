import { config } from "dotenv";
import { OpenAI } from "openai/index.mjs";
import chalk from "chalk";
import { createInterface } from "readline";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { existsSync } from "fs";

// Load environment variables
config();

// Check if .env file exists and has API key
const currentFilePath = fileURLToPath(import.meta.url);
const rootDirPath = dirname(dirname(currentFilePath));
const envFilePath = join(rootDirPath, ".env");

if (!existsSync(envFilePath) || !process.env.DEEPSEEK_API_KEY) {
  console.error(chalk.red("Error: DEEPSEEK_API_KEY not found!"));
  console.log(
    chalk.yellow(
      `Please create a .env file in the project root with your DeepSeek API key:`
    )
  );
  console.log(chalk.yellow(`DEEPSEEK_API_KEY=your_deepseek_api_key_here`));
  process.exit(1);
}

// Initialize DeepSeek client (using OpenAI SDK with DeepSeek baseURL)
const deepseek = new OpenAI({
  baseURL: "https://api.deepseek.com",
  apiKey: process.env.DEEPSEEK_API_KEY,
});

// Initialize readline interface
const rl = createInterface({
  input: process.stdin,
  output: process.stdout,
});

// Message history
const messageHistory: Array<{
  role: "system" | "user" | "assistant";
  content: string;
}> = [
  {
    role: "system",
    content:
      "You are a helpful assistant. Provide concise, accurate responses.",
  },
];

// Helper function to ask a question and return a promise
function askQuestion(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, (answer) => {
      resolve(answer);
    });
  });
}

// Function to generate a response from DeepSeek
async function generateResponse(
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>
) {
  try {
    const stream = await deepseek.chat.completions.create({
      model: "deepseek-chat", // DeepSeek-V2 model
      messages,
      stream: true,
    });

    // For streaming response
    process.stdout.write(chalk.green("AI: "));

    let fullResponse = "";

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        process.stdout.write(content);
        fullResponse += content;
      }
    }

    console.log("\n"); // Add newline after response
    return fullResponse;
  } catch (error: any) {
    console.error(chalk.red(`Error: ${error.message}`));
    return "Sorry, I encountered an error processing your request.";
  }
}

// Main chat loop
async function startChat() {
  console.log(chalk.blue("=== DeepSeek AI Console Chatbot ==="));
  console.log(chalk.blue("Type your messages to chat with AI."));
  console.log(chalk.blue("Commands:"));
  console.log(chalk.blue("  /exit - Exit the chat"));
  console.log(chalk.blue("  /reset - Reset conversation history"));
  console.log(chalk.blue("===============================\n"));

  while (true) {
    const userInput = await askQuestion(chalk.yellow("You: "));

    // Handle commands
    if (userInput.trim().toLowerCase() === "/exit") {
      console.log(chalk.blue("Goodbye!"));
      rl.close();
      break;
    } else if (userInput.trim().toLowerCase() === "/reset") {
      console.log(chalk.blue("Conversation history has been reset."));
      // Keep the system message but remove all other messages
      messageHistory.splice(1);
      continue;
    }

    // Add user message to history
    messageHistory.push({ role: "user", content: userInput });

    // Generate and display AI response
    const aiResponse = await generateResponse(messageHistory);

    // Add AI response to history
    messageHistory.push({ role: "assistant", content: aiResponse });
  }
}

// Start the chat
startChat().catch((error) => {
  console.error(chalk.red(`Fatal error: ${error.message}`));
  process.exit(1);
});
