# DeepSeek Console Chatbot

A simple interactive command-line chatbot built with Node.js and TypeScript that uses DeepSeek's API to have natural conversations.

## Features

- 💬 Interactive chat interface in the terminal
- 🧠 Maintains conversation history for context
- 🎨 Colored output for better readability
- ⚡ Streaming responses in real-time
- 🔄 Commands to reset conversation or exit

## Prerequisites

- Node.js (v16 or higher)
- DeepSeek API key (get one from [DeepSeek Platform](https://platform.deepseek.com/api_keys))

## Installation

1. Clone this repository or download the source code.

2. Install dependencies:

   ```bash
   npm install
   ```

3. Create a `.env` file in the project root directory and add your DeepSeek API key:
   ```
   DEEPSEEK_API_KEY=your_deepseek_api_key_here
   ```

## Usage

Start the chatbot:

```bash
npm start
```

### Commands

- Type your message and press Enter to chat with the AI
- `/reset` - Reset the conversation history
- `/exit` - Exit the application

## Configuration

You can modify the following in `src/index.ts`:

- AI model (default is 'deepseek-chat', which points to DeepSeek-V3-0324)
- System prompt (the initial instructions given to the AI)
- Output colors and formatting

## About DeepSeek Models

DeepSeek provides several model options:

- `deepseek-chat` - General purpose chat model (DeepSeek-V3-0324)
- `deepseek-reasoner` - Specialized for reasoning tasks (DeepSeek-R1-0528)

## License

ISC
